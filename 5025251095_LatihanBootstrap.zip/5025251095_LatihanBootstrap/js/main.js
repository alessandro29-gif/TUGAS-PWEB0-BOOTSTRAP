var menuKantin = [
{ id: 1, nama: "Nasi Ayam Penyet", kategori: "makanan", harga: 18000, gerai: "Warung Bu Tini", deskripsi: "Nasi hangat disajikan dengan ayam goreng renyah yang dipenyet di atas sambal pedas gurih." },
{ id: 2, nama: "Rawon Daging", kategori: "makanan", harga: 22000, gerai: "Rawon Pak Hadi", deskripsi: "Sup daging sapi berkuah hitam khas kluwek dengan cita rasa gurih kaya rempah." },
{ id: 3, nama: "Lontong Balap", kategori: "makanan", harga: 14000, gerai: "Dapur Suroboyo", deskripsi: "Potongan lontong dengan tauge, tahu goreng, dan lentho yang disiram kuah gurih beraroma khas." },
{ id: 4, nama: "Nasi Goreng Kampung", kategori: "makanan", harga: 15000, gerai: "Warung Bu Tini", deskripsi: "Nasi goreng khas rumahan dengan bumbu simpel yang rasanya gurih dan nagih." },
{ id: 5, nama: "Mie Ayam Bakso", kategori: "makanan", harga: 16000, gerai: "Mie Mas Joko", deskripsi: "Mie kenyal disiram tumisan ayam gurih manis, makin lengkap dengan tambahan bakso daging." },
{ id: 6, nama: "Rujak Cingur", kategori: "makanan", harga: 17000, gerai: "Dapur Suroboyo", deskripsi: "Campuran sayur, lontong, dan cingur sapi yang disiram bumbu petis khas Jawa Timuran." },
{ id: 7, nama: "Es Teh Manis", kategori: "minuman", harga: 4000, gerai: "Es Segar 24", deskripsi: "Teh manis dingin yang pas buat penyegar dahaga habis makan." },
{ id: 8, nama: "Es Kopi Susu Gula Aren", kategori: "minuman", harga: 12000, gerai: "Kopi Pojok", deskripsi: "Perpaduan espresso, susu segar, dan gula aren yang manisnya pas di lidah." },
{ id: 9, nama: "Jus Alpukat", kategori: "minuman", harga: 13000, gerai: "Es Segar 24", deskripsi: "Olahan buah alpukat asli yang kental, manis, dan creamy." },
{ id: 10, nama: "Es Degan", kategori: "minuman", harga: 8000, gerai: "Es Segar 24", deskripsi: "Es kelapa muda segar yang cocok banget diminum pas cuaca panas." },
{ id: 11, nama: "Tahu Crispy", kategori: "snack", harga: 8000, gerai: "Gorengan Mbak Rina", deskripsi: "Tahu goreng dengan balutan tepung renyah di luar dan lembut di dalam." },
{ id: 12, nama: "Pisang Goreng Keju", kategori: "snack", harga: 10000, gerai: "Gorengan Mbak Rina", deskripsi: "Pisang goreng renyah dengan taburan keju parut gurih dan manis di atasnya." },
{ id: 13, nama: "Risoles Mayo", kategori: "snack", harga: 6000, gerai: "Gorengan Mbak Rina", deskripsi: "Risoles gurih berisi isian gurih dan saus mayones yang lumer di mulut." },
{ id: 14, nama: "Cireng Bumbu Rujak", kategori: "snack", harga: 7000, gerai: "Gorengan Mbak Rina", deskripsi: "Cireng goreng yang kenyal-gurih, disajikan lengkap dengan cocolan bumbu rujak pedas manis." }
];

var kategoriAktif = "semua";
var kataKunci = "";
var daftarMenu = document.getElementById("daftar-menu");
var infoKosong = document.getElementById("info-kosong");
var kolomCari = document.getElementById("cari-menu");
var tombolFilter = document.querySelectorAll(".btn-filter");

function rupiah(angka) {
return "Rp" + angka.toLocaleString("id-ID");
}

function namaKategori(kode) {
if (kode === "makanan") return "Makanan";
if (kode === "minuman") return "Minuman";
return "Snack";
}

function tampilkanMenu() {
var hasil = menuKantin.filter(function (item) {
var cocokKategori = kategoriAktif === "semua" || item.kategori === kategoriAktif;
var cocokKata = item.nama.toLowerCase().indexOf(kataKunci) !== -1 || item.gerai.toLowerCase().indexOf(kataKunci) !== -1;
return cocokKategori && cocokKata;
});

var html = "";
hasil.forEach(function (item) {
html += '<div class="col-xs-12 col-sm-6 col-md-4 col-lg-3">';
html += '<article class="kartu">';
html += '<div class="thumb thumb-' + item.kategori + '">' + namaKategori(item.kategori) + '</div>';
html += '<div class="isi">';
html += '<h3>' + item.nama + '</h3>';
html += '<p class="gerai">' + item.gerai + '</p>';
html += '<div class="aksi">';
html += '<span class="harga">' + rupiah(item.harga) + '</span> ';
html += '<button type="button" class="btn btn-link btn-detail" data-id="' + item.id + '">Lihat detail</button>';
html += '</div></div></article></div>';
});

daftarMenu.innerHTML = html;
infoKosong.style.display = hasil.length === 0 ? "block" : "none";
}

function bukaDetail(id) {
var item = menuKantin.filter(function (m) { return m.id === id; })[0];
document.getElementById("modal-nama").textContent = item.nama;
document.getElementById("modal-gerai").textContent = item.gerai + " - " + namaKategori(item.kategori);
document.getElementById("modal-deskripsi").textContent = item.deskripsi;
document.getElementById("modal-harga").textContent = rupiah(item.harga);
$("#modal-detail").modal("show");
}

tombolFilter.forEach(function (tombol) {
tombol.addEventListener("click", function () {
kategoriAktif = tombol.getAttribute("data-kategori");
tombolFilter.forEach(function (t) { t.classList.remove("aktif"); });
tombol.classList.add("aktif");
tampilkanMenu();
});
});

kolomCari.addEventListener("input", function () {
kataKunci = kolomCari.value.trim().toLowerCase();
tampilkanMenu();
});

daftarMenu.addEventListener("click", function (e) {
if (e.target.classList.contains("btn-detail")) {
bukaDetail(parseInt(e.target.getAttribute("data-id"), 10));
}
});

tampilkanMenu();
